
import './App.css';
import Header from './Header.js';
import Home from './Home.js';

function App(){
  return(
    <div className="App">
      {/* <h1>Hello, Lets check</h1> */}

     {/* Header */}
    <Header />
    {/* Home */}
    <Home />
    </div>
    )
}


export default App